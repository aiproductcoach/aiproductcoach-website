---
layout: portfolios
title: "Portfolios"
permalink: /portfolios/

# Portfolios
portfolios:
  heading: "Our Latest Projects"
  description: "When unknow printer took a gallery of type and scramblted it to make a type specimen book"

# Testimonials
testimonials:
  heading: "What People Say"
  description: "When unknow printer took a gallery of type and scramblted it to make a type specimen book"
  list:
    - name: "John Doe"
      position: "Freelancer UX Designer"
      image: "/assets/images/testimonial_1.jpg"
      text: "Donec condimentum vehicula iaculis. Maecenas in aliquet neque. Suspendisse viverra, ante eget pellentesque pulvinar, nunc nisi molestie ligula, vitae convallis orci justo vitae sem. Integer vitae imperdiet augue, sed accumsan diam. Etiam non quam commodo dolor convallis cursus. Duis tempus dolor eget gravida fringilla. In ultricies velit eget sem tempus egestas."
    - name: "Jake Johnson"
      position: "Freelancer UX Designer"
      image: "/assets/images/testimonial_2.jpg"
      text: "Donec condimentum vehicula iaculis. Maecenas in aliquet neque. Suspendisse viverra, ante eget pellentesque pulvinar, nunc nisi molestie ligula, vitae convallis orci justo vitae sem. Integer vitae imperdiet augue, sed accumsan diam. Etiam non quam commodo dolor convallis cursus. Duis tempus dolor eget gravida fringilla. In ultricies velit eget sem tempus egestas."
    - name: "Celesto Anderson"
      position: "Freelancer UX Designer"
      image: "/assets/images/testimonial_3.jpg"
      text: "Donec condimentum vehicula iaculis. Maecenas in aliquet neque. Suspendisse viverra, ante eget pellentesque pulvinar, nunc nisi molestie ligula, vitae convallis orci justo vitae sem. Integer vitae imperdiet augue, sed accumsan diam. Etiam non quam commodo dolor convallis cursus. Duis tempus dolor eget gravida fringilla. In ultricies velit eget sem tempus egestas."

# Contact Area
contact_area:
  heading: "Get In Touch With Us"
  description: "When unknow printer took a gallery of type and scramblted it to make a type specimen book"
---

